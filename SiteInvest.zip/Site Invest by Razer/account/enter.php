<?php
defined('ACCESS') or die();
if ($login) {

	if($_GET['pay'] == "no") {
		print '<p class="er">Unable to top-up</p>';
	}

	if($_GET['refresh']) {

		$id = intval($_GET['refresh']);

			$sql	= 'SELECT * FROM `enter` WHERE `id` = '.$id.' LIMIT 1';
			$rs		= mysql_query($sql);
			$r		= mysql_fetch_array($rs);

			if($r['status'] == 2) {
				print '<p class="erok">Payment is completed</p>';
			} elseif($r['status'] == 5) {
				print '<p class="er">Payment canceled</p>';
			} elseif(!$r['btc']) {
				print '<p class="er">Payment is not recognized</p>';
			} else {

				include '../includes/bitcoin.php';

				$sum = GetBalanceAdress($r['btc'], $apikey, $cfgURL);
				
				if($sum == $r['curs']) {
					$pay = 1;
				} else {
					$pay = 0;
				}

				if($pay == 1) {

					mysql_query('UPDATE users SET pm_balance = pm_balance + '.$r['sum'].' WHERE login = "'.$login.'" LIMIT 1');
					mysql_query("UPDATE enter SET status = 2, purse = 'BitCoin' WHERE id = ".$id." LIMIT 1");

					print '<p class="erok">Payment credited</p>';
					print '<p align="center"><input onclick=\'top.location.href="/deposits/"\' class="subm" type="button" value=" Back " /></p>';
				} else {
					print '<p class="warn">We expect confirmation of payment on request: <b>'.intval($_GET['refresh']).'</b></p>';
					print '<p align="center"><input onclick=\'top.location.href="?refresh='.intval($_GET['refresh']).'"\' class="subm" type="button" value=" I made a payment, check your receipt once " /></p>';
				}

			}

	} elseif($_GET['conf']) {

		print '<p class="erok">Your application is sent to the administrator for review</p>';

		$conf		= intval($_GET['conf']);
		$purse		= addslashes(htmlspecialchars($_POST["purse"], ENT_QUOTES, ''));

		mysql_query("UPDATE enter SET status = 1, purse = '".$purse."' WHERE id = ".$conf." LIMIT 1");

	} elseif($_GET['action'] == 'save') {

		$sum	= sprintf ("%01.2f", str_replace(',', '.', $_POST['sum']));
		$ps		= intval($_POST['ps']);

		if ($sum <= 0) {
			print '<p class="er">Enter the correct amount (from $ 0.10 up to $ 10,000)!</p>';
		} elseif ($sum < 0.10 || $sum > 10000) {
			print '<p class="er">At a time is allowed to enter from $ 0.10 up to $ 10,000!</p>';
		} elseif($ps < 1) {
			print '<p class="er">Specify the payment system!</p>';
		} else {

			$get_ps	= mysql_query("SELECT * FROM `paysystems` WHERE id = ".$ps." LIMIT 1");
			$rowps	= mysql_fetch_array($get_ps);
		
			$sql = 'INSERT INTO `enter` (`sum`, `date`, `login`, `paysys`, `service`) VALUES ('.$sum.', '.time().', "'.$login.'", "'.$rowps['name'].'", "bal")';
			mysql_query($sql);
			$lid = mysql_insert_id();
		
			if(file_exists("ps/".$rowps['filename']."_en.php")) {
				include "ps/".$rowps['filename']."_en.php";
			} else {
				include "ps/index_en.php";
			}		
		
		}
	} else {
	?>
	<FIELDSET style="border: solid #666666 1px; padding-top: 15px; margin-bottom: 10px;">
	<LEGEND><b>Form balance replenishment</b></LEGEND>
	<table align="center">
	<form action="?action=save" method="post">
	<tr><td><b>Amount</b>: </td><td align="right"><input style="width: 180px;" type='text' name='sum' value='' size="30" maxlength="7" /></td></tr>
	<tr><td><b>Payment System</b>: </td><td align="right">
	<select style="width: 180px; margin-right: 0px;" name="ps">
		<?php
			$result	= mysql_query("SELECT * FROM `paysystems` WHERE view = 1 ORDER BY id ASC");
			while($row = mysql_fetch_array($result)) {
				print '<option value="'.$row['id'].'">'.$row['name'].'</option> ';
			}
		?>
	</select></td></tr>
	<tr><td></td><td align="right"><input class="subm" type='submit' name='submit' value=' Fill up balance ' /></td></tr>
	</form>
	</table></FIELDSET><hr />

<h3>History completions:</h3>
<?php


	$page	= intval($_GET['page']);
	$query	= "SELECT * FROM `enter` WHERE login = '".$login."'";
	$result	= mysql_query($query);
	$themes = mysql_num_rows($result);
	$total	= intval(($themes - 1) / $num) + 1;

	if(empty($page) or $page < 0) $page = 1;
	if($page > $total) $page = $total;
	$start = $page * $num - $num;
	$result = mysql_query($query." ORDER BY id DESC LIMIT ".$start.", ".$num);

	if(!$themes) {
		print "<p class=\"er\">You have not filed applications for top-ups!</p>";
	} else {

		print "<table width=\"100%\"><tr bgcolor=\"#dddddd\" align=\"center\"><td style=\"padding: 3px;\"><b>#</b></td><td width=\"100\"><b>Date</b></td><td><b>Amount</b></td><td><b>Account</b></td><td><b>System</b></td><td><b>Status</b></td></tr>";

		$i = 1;
		$s = 0;
		while ($row = mysql_fetch_array($result)) {

		if($i % 2) { $bg = ""; } else { $bg = " bgcolor=\"#eeeeee\""; }

		print "<tr".$bg." align=\"center\">
		<td style=\"padding: 3px;\">".$row['id']."</td>
		<td>".date("d.m.Y H:i", $row['date'])."</td>
		<td>$".$row['sum']."</td>
		<td><b>".$row['purse']."</b></td>
		<td>".$row['paysys']."</td>
		<td>";

		if($row['status'] == 0 && $row['btc']) {
			print '<span class="tool"><a href="?refresh='.$row['id'].'"><img src="/images/proc_ico.png" width="16" height="16" alt="In the process" /></a><span class="tip">The application is created, but not yet confirmed. Check payment.</span></span>';
		} elseif($row['status'] == 0) {
			print '<span class="tool"><img src="/images/proc_ico.png" width="16" height="16" alt="during" /><span class="tip">The application is created, but not yet confirmed payment from your side</span></span>';
		} elseif($row['status'] == 1) {
			print '<span class="tool"><img src="/images/wait_ico.png" width="16" height="16" alt="expectation" /><span class="tip">The application is under consideration and treatment.</span></span>';
		} elseif($row['status'] == 2) {
			print '<span class="tool"><img src="/images/yes_ico.png" width="16" height="16" alt="performed" /><span class="tip">application is made!</span></span>';
		} else {
			print '<span class="tool"><img src="/images/no_ico.png" width="16" height="16" alt="rejected" /><span class="tip">application rejected.</span></span>';
		}

		print "</td>

		</tr>";

			$i++;
			$s = $s + $row['sum'];
		}

		print "<tr bgcolor=\"#dddddd\" height=\"3\"><td></td><td></td><td></td><td></td><td></td><td></td></tr>
		<tr><td></td><td align=\"right\"><b>Total:</b></td><td align=\"center\"><b>$".$s."</b></td><td></td><td></td><td></td></tr></table>";

	}

	if ($page) {
		if($page != 1) { $pervpage = "<a href=\"?page=". ($page - 1) ."\">��</a>"; }
		if($page != $total) { $nextpage = " <a href=\"?page=".$total."\">��</a>"; }
		if($page - 2 > 0) { $page2left = " <a href=\"?page=". ($page - 2) ."\">". ($page - 2) ."</a> "; }
		if($page - 1 > 0) { $page1left = " <a href=\"?page=". ($page - 1) ."\">". ($page - 1) ."</a> "; }
		if($page + 2 <= $total) { $page2right = " <a href=\"?page=". ($page + 2) ."\">". ($page + 2) ."</a> "; }
		if($page + 1 <= $total) { $page1right = " <a href=\"?page=". ($page + 1) ."\">". ($page + 1) ."</a> "; }
	}
	print "<div class=\"pages\"><b>Pages:  </b>".$pervpage.$page2left.$page1left." <b>".$page."</b> ".$page1right.$page2right.$nextpage."</div>";

	}

} else {
	print "<p class=\"er\">You must login to access this page!</p>";
}

?>