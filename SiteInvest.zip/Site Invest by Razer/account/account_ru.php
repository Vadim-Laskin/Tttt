﻿<script language="javascript" src="/files/scripts.js"></script>


	<div class="content" data-ix="anim-load">
    <div class="columns-account w-row">
        <div class="col-left w-col w-col-6 w-col-stack">
            <div class="block-balance bal-mob">
                <div>
                    <div>Мой баланс</div>
                    <div class="balance__sum"><span><?php print sprintf ("%01.2f", str_replace(',', '.', ($a8['lr_balance'] + $a8['pm_balance'])));?></span> <span class="balance__currency">₽</span></div>
                </div>
                <div class="balance__sum-other">
                    <div class="balance__sum-other__col">
                        <div>Инвестировано</div>
                        <div class="balance__sum-other__elem"><span><?php print sprintf ("%01.2f", str_replace(',', '.', $alldep));?></span><span> ₽</span></div>
                    </div>
                    <div class="balance__sum-other__col">
                        <div>Выведено</div>
                        <div class="balance__sum-other__elem"><span><?php print sprintf ("%01.2f", str_replace(',', '.', $allout));?></span><span> ₽</span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-right col--replenish w-col w-col-6 w-col-stack">
            <div class="block mod--replenish-account">
                <div class="replenish-account__cont"><img src="/assets/lk/images/icon-composit-2.svg" alt="" class="ico">
                    <div class="replenish-account__info">
                        <h5 class="replenish-account__title">Пополните баланс и заключите контракт</h5>
                        <div class="replenish-account__info__block">
                            <div class="replenish__info__text mod--first"><span>Минимальная сумма:</span> <span class="replenish__info__text__blue">1000</span><span class="replenish__info__text__blue"> ₽</span></div>
                            <div class="replenish__info__text"><span>Комиссия:</span> <span class="replenish__info__text__blue">0</span> <span class="replenish__info__text__blue">%</span></div>
                        </div>
                    </div>
                </div>
                <div class="replenish-account__wrap-buttons"><a href="/enter" class="btn btn--replenish-account w-button">Пополнить баланс</a><a href="/deposit" class="btn btn--border w-button">Заключить контракт</a></div>
            </div>
        </div>
    </div>
    <div class="columns-account-2 w-row">
        <div class="col-left w-col w-col-8 w-col-stack">
            <div class="block block--operations">
                <div class="wrap-operations">
				
                    <div class="wrap-title wrap--operations">
                        <h4 class="block__title">Мои контракты</h4><a href="/deposits" class="all-operations"><span>Полный список</span> <span class="link__arrow"></span></a></div>

					 						<?php
defined('ACCESS') or die();
if($login) {

	if($_GET['close']) {

		$result	= mysql_query("SELECT * FROM deposits WHERE id = ".intval($_GET['close'])." AND user_id = ".$user_id." AND status = 0 LIMIT 1");
		$row	= mysql_fetch_array($result);

		$result2	= mysql_query("SELECT * FROM plans WHERE id = ".$row['plan']." LIMIT 1");
		$row2		= mysql_fetch_array($result2);

		if(!$row['id'] || !$row2['id']) {
			print '<p class="er">Произошла ошибка при закрытии депозита</p>';
		} elseif($row2['back'] != 1 || $row2['close'] != 1) {
			print '<p class="er">Этот депозит невозможно закрыть досрочно</p>';
		} else {
			$sum = sprintf("%01.2f", $row['sum'] - $row['sum'] / 100 * $row2['close_percent']);
			mysql_query('UPDATE users SET pm_balance = pm_balance + '.$sum.' WHERE id = '.$row['user_id'].' LIMIT 1');
			mysql_query("DELETE FROM deposits WHERE id = ".$row['id']." LIMIT 1");
			print '<p class="erok">ДЕПОЗИТ ЗАКРЫТ ДОСРОЧНО!</p>';
		}

	}
?>












 <div class="table acc_table">
                        <div class="table__li mod--title">
                            <div class="table__top-columns mob--hide w-row">
                                <div class="table__col col-operation--1 w-col w-col-3">
                                    <div class="table__col__title">Сумма контракта</div>
                                </div>
                                <div class="table__col col-operation--2 w-col w-col-3">
                                    <div class="table__col__title">Доходность</div>
                                </div>
                                <div class="table__col col-operation--3 w-col w-col-3">
                                    <div class="table__col__title">Дата заключения</div>
                                </div>
                                <div class="table__col col-operation--4 w-col w-col-3">
                                    <div class="table__col__title">Статус</div>
                                </div>
                            </div>
                        </div>
																						                                    												                        <div class="table__list">
     












<?php
$s = 0;
$result	= mysql_query("SELECT * FROM deposits WHERE user_id = ".$user_id." ORDER BY id ASC");
while($row = mysql_fetch_array($result)) {

	$result2	= mysql_query("SELECT * FROM plans WHERE id = ".$row['plan']." LIMIT 1");
	$row2		= mysql_fetch_array($result2);

print "





                       <div class='table__li'>
                                <div class='table__columns w-row'>

                                    <div class='table__col col-operation--1 w-col w-col-3'>

										<div class='table__col__mob-show'>

                                            <div class='table__col__title'>Сумма контракта</div>
                                        </div>
                                        <div class='transaction-check mob--hide'><img src='/assets/lk/images/icon-check.svg' alt=''></div>
                                        <div><span>".$row['sum']." ".$moneycurr."</span><span> ₽</span></div>
                                    </div>
                                    <div class='table__col col-operation--2 w-col w-col-3'>
                                        <div class='table__col__mob-show'>
                                            <div class='table__col__title'>Доходность</div>
                                        </div>
                                        <div class='operations__wrap-param'><span>".$row2['percent']."</span><span> %</span><div class='history__param percent_param'>В неделю</div></div>
                                        <div id='tooltip-contract' class='tooltip tooltip-profile'>
                                            <div class='info__ico'></div>
                                            <div class='info__notice'>
                                                <div class='info__text'>Прибыль по контракту начисляется еженедельно и доступна для вывода в любое время</div><img src='images/tooltip-poligon.svg' alt='' class='notice__polygon'></div>
                                        </div>
                                        
                                    </div>
                                    <div class='table__col col-operation--3 w-col w-col-3'>
                                        <div class='table__col__mob-show'>
                                            <div class='table__col__title'>Дата заключения</div>
                                        </div>
                                        <div class='operations__wrap-param'><span>".date("d.m.Y H:i", $row['date'])."</span><div class='history__param'><span id=\"deptimer".$row['id']."\"></span></b> [ ".date("H:i d.m.Y", $row['nextdate'])." ]</div></div>
                                    </div>
                                    <div class='table__col col-operation--4 w-col w-col-3'>
                                        <div class='table__col__mob-show'>
                                            <div class='table__col__title'>Статус</div>
                                        </div>
                                        <div class='status status--work'>
                                            <div><span class='tnx-type-md badge badge-outline badge-success badge-md'>Активный</span></div>
                                        </div>
										
                                    </div>
									
                                </div>
                            </div>
                        </div>  ";
	
	if($row2['back'] == 1 && $row2['close'] == 1) {
		print " [ <a href=\"javascript: if(confirm('Вы действительно хотите закрыть депозит? При закрытии депозита, с вас будет вычтена комиссия в размере ".$row2['close_percent']."%')) top.location.href='?close=".$row['id']."';\">Закрыть депозит</a> ]";
	}
	
	print "";
	
	print "";

if(cfgSET('autopercent') == "on") {
print "<tr>
	
</tr>
<tr>
	<td class=\"lineclock\">
		<div id=\"percentline".$row['id']."\" class=\"percentline\">&nbsp;</div>
		<script language=\"JavaScript\">
		<!--
			CalcTimePercent(".$row['id'].", ".$row['lastdate'].", ".$row['nextdate'].", ".time().", ".$row2['period'].");
		//-->
		</script>
	</td>
</tr>
<tr>
	<td height=\"1\" bgcolor=\"#0180ff\"></td>
</tr>";
}

print "";
$s = $s + $row['sum'];
}
?>

</div>


<?php 

	if($s == 0) {
		print '<div class="content" data-ix="anim-load">
	                     <div class="block block--operations ">
            <div class="noresult" style="padding-left:16px; padding-right:16px;"><img src="/assets/lk/images/icon-composit-5.svg" alt="">
                <h4 class="noresult__title">Вы не заключили контракты</h4><a href="/deposit" class="btn w-button">Заключить контракт</a></div>

	</div>

</div>
	';
	} else {
		print ''.$moneycurr;
	}

} else {
	print "<p class=\"er\">Для доступа к данной странице вам необходимо авторизироваться</p>";
	include "../login/login_ru.php";
}
?>

                    </div>						
				</div>
            
			        </div>
		
        
        
        
        <div class="col-sidebar w-col w-col-4 w-col-stack adm_calc">
            <div class="block block--calculator">
                <div class="wrap-title">
                    <h4 class="block__title">Калькулятор прибыли</h4>
                </div>
                <div class="calculator__cont">
                    <!--<div class="block-form w-form">
                        <form id="wf-form-Email-Form" name="wf-form-Email-Form" data-name="Email Form" class="form-select mod--calculator">
                            <div>
                                <label for="Sum-4" class="label label--grey">Сумма</label>
                                <div class="form__wrap-sum">
                                    <input type="text" class="input input--sum w-input" maxlength="256" name="Sum-2" data-name="Sum 2" placeholder="Сумма" id="deposit_amount__calc">
                                    <span style="padding-left:16px">RUB</span>
                                    
                                </div>
                            </div>
                            <div class="form-sum__total">
                                <div class="form-sum__total__sum" ><input class="" type="text" placeholder="0 руб" id="calcul_val__1" readonly="readonly"></div>
                                <div>ежедневно</div>
                            </div>
                        </form>
                        <div class="w-form-done">
                            <div>Thank you! Your submission has been received!</div>
                        </div>
                        <div class="w-form-fail">
                            <div>Oops! Something went wrong while submitting the form.</div>
                        </div>
                    </div>
                    
                    
                    <div class="calculator__wrap-btn">
                        <div class="calculator__text">Прибыль по контракту начисляется ежедневно!</div>
                        <a href="/account/payment" class="btn mod--calculator w-button">Вывести прибыль</a>
                    </div>-->
                    
                    
                    
                    <div class="calculate">
                                	
                        <div class="c_rezult">
                            <div class="c_rezult-flex">
                                <input id="rezult-range" type="text" class="input w-input js-input" value="1000">
                                <div class="c_val">рублей</div>
                            </div>
                        </div>
                        
                        <div class="range-slider">
                            <input id="range-slider" type="text" class="js-range-slider" value="" />
                        </div>
                        
                        <div class="c_period">
                            <label>Выберите период</label>
                            <select id="c_period" class="select--custom w-select">
                                <option value="1">Ежедневно</option>
                                <option value="4">Месяц</option>
                                <option value="25">180 дней</option>
                            </select>
                        </div>
                        
                    </div>
                    <div class="bottom_с_p">
                        <p class="с_p">Контракт заключается на 180 дней.<br/> Прибыль начисляется ежедневно.</p>
                    </div>
                    
                   
                    
                    
                </div>
            </div>
            
            
            <div class="calculate_profit">
                <div class="c_tit">Ваш доход составит</div>
                <div id="calculate_rezult">
                    <span id="calculate__rezult" class="value-main">15</span>
                    <span class="value-sub"><span id="calculate__rezult2">.00</span><span class="balance__currency">₽</span></span>
                </div>
            </div>
            
        </div>
		
    </div>
</div>     