// Кастомный файл для скриптов. Дописывать дополнительные скрипты в него.
// 
// 
// инициализация кастомного select
$(document).ready(function() {
	$('.select--custom').select2({
		minimumResultsForSearch: Infinity,
	});
});

// инициализация tooltip
$(document).ready(function() {
	tippy('.tooltip-profile', {
		placement: 'top-start',
		content: "Прибыль по контракту<br>начисляется ежедневно,<br>а вывод прибыли доступен<br>в любое время.",
	});
});
$(document).ready(function() {
	tippy('.tooltip-contract', {
		placement: 'top-start',
		content: "Прибыль по контракту<br>начисляется ежедневно,<br>а вывод прибыли доступен<br>в любое время.",
	});
});

// dropdown для блока "просмотр" на странице тикетов в моб. версии
$(document).ready(function() {
	$('.dropdown-buttons.mod--ticket').on('click', function() {
		$('.block--profile-open, .block--view-mob').toggleClass("open");
	});
});

// dropdown для блоков на странице "настройки"
$(document).ready(function() {
	$(".title--dropdown, .dropdown-buttons").click(function() {
		$(this).siblings(".dropdown__cont").slideToggle('medium');
		$(this).siblings('.dropdown-buttons').children('.btn-plus').toggleClass('btn-plus-hide');
	});
});

// стилизация input, required
$(document).ready(function() {
	$('form .w-button[type="submit"]').on('click', function() {
		$('input[required]').addClass('input--req');
	});
});

// добавление блоку способа вывода/пополнения активный класса
$(document).ready(function() {
	$('.balance-method__card').on('click', function() {
		$('.balance-method__card').removeClass("active");
		$(this).toggleClass("active");
		return false;
	});
});

// добавление радио кнопки активного класса на странице "заключить контракт"
$(document).ready(function() {
	$('.contract__radio').on('click', function() {
		$('.contract__radio').removeClass("active");
		$(this).addClass("active");
	});
});

// переключения на второй таб (блока сообщения) на страинице "открыть тикет"
$(document).ready(function() {
	$('.ticket__radio').on('click', function() {
		$(".tabs__menu__link.tab--2").click();
	});
	$('#btn-cancel').on('click', function() {
		$(".tabs__menu__link.tab--1").click();
	});
});

// подмена текста при выборе контракта на странице "заключить контракт" 
$(document).ready(function() {
	$(".contract__radio").change(function() {
		if ($('#check-eth').prop("checked")) {
			$('#sum-notice-2').fadeOut(100);
			$('#sum-notice-1').delay(200).fadeIn(100);
		} else {
			$('#sum-notice-1').fadeOut(100);
			$('#sum-notice-2').delay(200).fadeIn(100);
		}
	});
});

// копирование содержимого в буфер с input 
// document.getElementById('btn-copy').addEventListener('click', function() {
// 	var copyText = document.getElementById("url-copy");
// 	copyText.select();
// 	document.execCommand("copy");
// 	alert("Ссылка скопирована");
// });