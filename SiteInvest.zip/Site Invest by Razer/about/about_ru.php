  <div data-w-id="0542c13b-b862-d0af-a6c2-24f83a95113e" class="screen page--head">
        <div class="screen__content">
            <div class="block-page-head">
                <h1 class="page-heading1">О компании</h1>
            </div>
        </div>
    </div>
    
    <div data-easing="linear" data-duration-in="300" data-duration-out="200" class="page-tabs w-tabs">
        <div class="page-tabs__nav w-tab-menu">
            <a data-w-tab="Tab 1" class="page-tabs__nav__link tab--1 w-inline-block w-tab-link w--current">
                <div>О нас</div>
            </a>
            <a data-w-tab="Tab 2" class="page-tabs__nav__link tab--2 w-inline-block w-tab-link">
                <div>Контакты</div>
            </a>
        </div>
        <div class="page-tabs__content w-tab-content">
            <div data-w-tab="Tab 1" class="page-tabs__tab w-tab-pane w--tab-active">
                <div class="screen screen--about">
                    <div class="screen__content">
                        <div class="block-about">
                            <div class="about__content cont--1">
                                <div class="about__wrap-text wrap--1">
                                    <h2 class="heading2">Кто мы?</h2>
                                    <p class="desc">
                                        Инвестиционная платформа, созданная профессионалами финансового рынка. На сегодняшний день с нами работают более 30 специалистов, каждый из которых имеет высокий кредит
                                        доверия и богатый (и что важно - успешный) опыт в своей сфере деятельности, позволяющие нам планировать прибыль и предлагать инвестиционные планы с высоким фиксированным процентом, что выгодно
                                        отличает Investcoin от многих конкурентов, а официальный статус на территории РФ является гарантом прозрачности нашей деятельности.
                                    </p>
                                </div>
                            </div>
                            <img src="/assets\images\Illustr-about.svg" alt="" class="about__img">
                        </div>
                    </div>
                </div>
                <div class="screen">
                    <div class="screen__content">
                        <div class="block-about about--2">
                            <img src="/assets\images\pg-about2.svg" alt="" class="about__img2">
                            <div class="about__content cont--2">
                                <div class="about__wrap-text wrap--2">
                                    <p class="about__subtitle">Нашей приоритетной задачей было создание лучшего инвестиционного сервиса,</p>
                                    <p class="desc">
                                        который включает в себя диверсифицированный портфель состоящий из таких направлений заработка, как криптовалютный трейдинг, участие в ICO (старт новых криптовалют), так же облачный майнинг.
                                    </p>
                                    <p class="desc">
                                        Все это мы объединили в один инвестиционный портфель и готовы предложить его нашим клиентам. Принцип работы состоит в следующем: инвесторы получают фиксированный процент согласно тарифу, а остальная
                                        часть прибыли остаётся в компании.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="screen screen--about-why">
                    <div class="screen__content">
                        <div class="block-about-why">
                            <div class="about-why__content">
                                <img src="index.htm" alt="" class="about-why__coins">
                                <img src="/assets\images\pg-about_phone.png" srcset="/assets\images\pg-about_phone-p-500.png 500w, /assets\images\pg-about_phone.png 763w" sizes="(max-width: 767px) 100vw, (max-width: 991px) 585px, 763px" alt="" class="about-why__phone">
                                <img src="/assets\images\pg-about_phone-mob.png" width="320" alt="" class="about-why__mob-phone">
                                <div class="about-why__wrap-text">
                                    <h2 class="heading2">Почему именно мы?</h2>
                                    <div class="about-why__wrap-p">
                                        <p class="about-why__p">
                                            В нашей платформе может участвовать абсолютно любой человек независимо от технических знаний или дохода, ведь минимальная сумма контракта всего 100 рублей, а интуитивно понятный личный кабинет не
                                            требует особых навыков, поэтому разобраться в нем не составит никакого труда.
                                        </p>
                                        <p class="about-why__p">
                                            Вам не нужно самому торговать на криптовалютных биржах, покупать оборудование для майнинга и т.д, все эти хлопоты берут на себя специалисты нашей компании. Вам же остается пройти простую
                                            регистрацию, заключить контракт на нужную вам сумму и получать ежедневный доход.
                                        </p>
                                        <p class="about-why__p">
                                            Так же с помощью нашей реферальной системы вы сможете зарабатывать еще больше, приглашая в проект друзей или знакомых, которые так же хотят зарабатывать, а вы в свою очередь будете получать 5% от суммы заключенных ими контрактов.
                                        </p>
                                        <div class="about-why__wrap-p__line"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
              
                
                
                
              

                <div class="screen">
                    <div class="screen__content">
                        <div class="block-payment">
                            <h2 class="heading2">Платежные системы</h2>
                            <div class="payment__content">
                                <div class="payment__wrap-card">
                                    <div class="payment__card"><img src="/assets\images\visa-logo.svg" alt="" class="payment__card__logo"></div>
                                </div>
                                <div class="payment__wrap-card">
                                    <div class="payment__card"><img src="/assets\images\mastercard-logo.svg" alt="" class="payment__card__logo"></div>
                                </div>
                                <div class="payment__wrap-card">
                                    <div class="payment__card"><img src="/assets\images\mir-logo.svg" alt="" class="payment__card__logo"></div>
                                </div>
                                <div class="payment__wrap-card">
                                    <div class="payment__card"><img src="/assets\images\payment-qiwi.svg" alt="" class="payment__card__logo"></div>
                                </div>
                                <div class="payment__wrap-card">
                                    <div class="payment__card"><img src="/assets\images\payment-yandex.svg" alt="" class="payment__card__logo"></div>
                                </div>
                                <div class="payment__wrap-card">
                                    <div class="payment__card"><img src="/assets\images\payment-payeer.svg" alt="" class="payment__card__logo"></div>
                                </div>
                            </div>
                            <div class="block-slider-payment">
                                <div class="payment-swiper">
                                    <div class="swiper-wrapper">
                                        <div class="swiper-slide">
                                            <div class="swiper-slide__content">
                                                <div class="payment__card"><img src="/assets\images\visa-logo.svg" alt="" class="payment__card__logo"></div>
                                            </div>
                                        </div>
                                        <div class="swiper-slide">
                                            <div class="swiper-slide__content">
                                                <div class="payment__card"><img src="/assets\images\mastercard-logo.svg" alt="" class="payment__card__logo"></div>
                                            </div>
                                        </div>
                                        <div class="swiper-slide">
                                            <div class="swiper-slide__content">
                                                <div class="payment__card"><img src="/assets\images\mir-logo.svg" alt="" class="payment__card__logo"></div>
                                            </div>
                                        </div>
                                        <div class="swiper-slide">
                                            <div class="swiper-slide__content">
                                                <div class="payment__card"><img src="/assets\images\payment-qiwi.svg" alt="" class="payment__card__logo"></div>
                                            </div>
                                        </div>
                                        <div class="swiper-slide">
                                            <div class="swiper-slide__content">
                                                <div class="payment__card"><img src="/assets\images\payment-yandex.svg" alt="" class="payment__card__logo"></div>
                                            </div>
                                        </div>
                                        <div class="swiper-slide">
                                            <div class="swiper-slide__content">
                                                <div class="payment__card"><img src="/assets\images\payment-payeer.svg" alt="" class="payment__card__logo"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-nav">
                                    <div class="swiper-pagination pagination--style2 payment--pagination">
                                        <div class="pagination__dot2"></div>
                                        <div class="pagination__dot2"></div>
                                        <div class="pagination__dot2"></div>
                                        <div class="pagination__dot2 active"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="screen">
                    <div class="screen__content">
                        <div class="faq__instruct instruct--about">
                            <div class="faq__instruct__cont">
                                <p class="faq__instruct__title br_mob">Пошаговая инструкция, <br>как начать зарабатывать</p>
                                <p class="faq__instruct__desc">Начни зарабатывать уже сегодня</p>
                            </div><a href="/start" class="button button--instruct w-button">Подробнее</a></div>
                        </div>
                    </div>
                </div>
            
            <div data-w-tab="Tab 2" class="page-tabs__tab w-tab-pane">
                <div class="screen screen--contacts">
                    <div class="screen__content">
                        <div class="contacts__columns">
                            <div class="contacts__col">
                                <div class="contacts__col__top"><img src="/assets\images\contacts_location-ico.svg" alt="" class="contacts__ico"></div>
                                <a href="mailto:support@Investcoin.com" class="contacts__text">support@investcoin.vip</a>
                            </div>
                            <div class="contacts__col">
                                <div class="contacts__col__top"><img src="/assets\images\contacts_locat-ico.svg" alt="" class="contacts__ico"></div>
                                <p class="contacts__text">

г. Москва,<br> ул. Сергея Эйзенштейна, дом 8</p>
                            </div>
                            <div class="contacts__col">
                                <div class="contacts__col__top">
                                    <div class="contacts__social">
                                        <a href="https://vk.com/" class="footer-site__social__link w-inline-block" target="_blank">
                                            <div></div>
                                        </a>
                                        <a href="https://www.youtube.com/channel/" class="footer-site__social__link w-inline-block" target="_blank">
                                            <div></div>
                                        </a>
                                        <a href="https://t.me/" class="footer-site__social__link w-inline-block" target="_blank">
                                            <div></div>
                                        </a>
                                    </div>
                                </div>
                                <p class="contacts__text text--social">
                                    Много интересного<br>
                                    в наших соц. сетях
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="screen screen--map">
                    <div class="screen__content">
                        <div class="contacts-form-block">
                            <form id="wf-form-contact-form" name="wf-form-contact-form" data-name="contact form" class="contacts-form">
                                <h3 class="contacts-form__title">Обратная связь</h3>
                                <p class="contacts-form__subtitle">Если у вас возникли вопросы или есть предложения по работе платформы Investcoin , оставьте заявку и мы ответим вам в ближайшее время.</p>
                                <div class="contacts-form__inputs">
                                    <div class="wrap-input-mat">
                                        <label for="node" class="label label--mat">Имя</label>
                                        <input type="text" maxlength="256" data-name="Имя" id="siupp_name" class="input input--mat w-input">
                                    </div>
                                    <div class="wrap-input-mat">
                                        <label for="email" class="label label--mat">E-mail</label>
                                        <input type="email" class="input input--mat w-input" maxlength="256" name="email" data-name="Email" id="siupp_email" required="">
                                    </div>
                                    <div class="wrap-input-mat input--area">
                                        <label for="Text" class="label label--mat">Ваше сообщение...</label>
                                        <textarea name="Text" maxlength="5000" id="siupp_message" data-name="Text" class="input input--mat input--area w-input"></textarea>
                                    </div>
                                    <input type="submit" value="Отправить" data-wait="Отправка..." class="button w-button">
                                </div>
                            </form>

                        </div>
                    </div>
                    <div id="map" class="contacts__map"></div>
            <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.4.1.min.220afd743d.js" type="text/javascript" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
              <script>
//Костамизация google карты
$(document).ready(function() {
	google.maps.event.addDomListener(window, 'load', init);
	function init() {
		var mapOptions = {
			disableDefaultUI: true,
			zoom: 15,
			scrollwheel: false,
			center: new google.maps.LatLng(55.7937178, 49.1492609),
			styles: [
    {
        "featureType": "water",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#e9e9e9"
            },
            {
                "lightness": 17
            }
        ]
    },
    {
        "featureType": "landscape",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#f5f5f5"
            },
            {
                "lightness": 20
            }
        ]
    },
    {
        "featureType": "road.highway",
        "elementType": "geometry.fill",
        "stylers": [
            {
                "color": "#ffffff"
            },
            {
                "lightness": 17
            }
        ]
    },
    {
        "featureType": "road.highway",
        "elementType": "geometry.stroke",
        "stylers": [
            {
                "color": "#ffffff"
            },
            {
                "lightness": 29
            },
            {
                "weight": 0.2
            }
        ]
    },
    {
        "featureType": "road.arterial",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#ffffff"
            },
            {
                "lightness": 18
            }
        ]
    },
    {
        "featureType": "road.local",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#ffffff"
            },
            {
                "lightness": 16
            }
        ]
    },
    {
        "featureType": "poi",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#f5f5f5"
            },
            {
                "lightness": 21
            }
        ]
    },
    {
        "featureType": "poi.park",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#dedede"
            },
            {
                "lightness": 21
            }
        ]
    },
    {
        "elementType": "labels.text.stroke",
        "stylers": [
            {
                "visibility": "on"
            },
            {
                "color": "#ffffff"
            },
            {
                "lightness": 16
            }
        ]
    },
    {
        "elementType": "labels.text.fill",
        "stylers": [
            {
                "saturation": 36
            },
            {
                "color": "#333333"
            },
            {
                "lightness": 40
            }
        ]
    },
    {
        "elementType": "labels.icon",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },
    {
        "featureType": "transit",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#f2f2f2"
            },
            {
                "lightness": 19
            }
        ]
    },
    {
        "featureType": "administrative",
        "elementType": "geometry.fill",
        "stylers": [
            {
                "color": "#fefefe"
            },
            {
                "lightness": 20
            }
        ]
    },
    {
        "featureType": "administrative",
        "elementType": "geometry.stroke",
        "stylers": [
            {
                "color": "#fefefe"
            },
            {
                "lightness": 17
            },
            {
                "weight": 1.2
            }
        ]
    }
],
		};
		var mapElement = document.getElementById('map');
		var map = new google.maps.Map(mapElement, mapOptions);
		var image = 'assets/images/point.png';
		var myLatLng = new google.maps.LatLng(55.7937178, 49.1492609);
		var mapMarker = new google.maps.Marker({
			position: myLatLng,
			map: map,
			icon: image,
		});
	}
});
</script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAut0y1-sAUh-40RGigK-8zhfU9Aza38Fk"></script>
<style>
.contacts__map iframe{width:100%; height:100%}
</style>

                </div>
            </div>
        </div>
    </div>
</main>
