<?php
	 print $body;
?>