﻿<?php
/*
Данный скрипт разработан Михайленко Виктором Леонидовичем, далее автор.
Любое использование данного скрипта, разрешено только с письменного согласия автора.
Дата разработки: 12.10.2007 г.

-> Файл обработчика формы и последующей отсылки данных на e-mail (контактная форма)
*/
defined('ACCESS') or die();
print $body;
$action = htmlspecialchars(str_replace("'","",substr($_GET['action'],0,6)));

	if($action == "submit") {
		$name		= htmlspecialchars(str_replace("'","",substr($_POST['name'],0,50)), ENT_QUOTES, '');
		$mail		= htmlspecialchars(str_replace("'","",substr($_POST['mail'],0,50)), ENT_QUOTES, '');
		$subj		= htmlspecialchars(str_replace("'","",substr($_POST['subj'],0,100)), ENT_QUOTES, '');
		$textform	= htmlspecialchars(str_replace("'","",substr($_POST['textform'],0,10240)), ENT_QUOTES, '');
		$code		= htmlspecialchars(str_replace("'","",substr($_POST['code'],0,5)), ENT_QUOTES, '');

		    if(!$name) {
				print "<p class=\"er\">Введите пожалуйста Ваше имя!</p>";
		}
		elseif(!$mail) {
				print "<p class=\"er\">Введите пожалуйста Ваш e-mail!</p>";
		}
		elseif(!$subj) {
				print "<p class=\"er\">Введите пожалуйста тему Вашего сообщения!</p>";
		}
		elseif(!$textform) {
				print "<p class=\"er\">Введите пожалуйста текст Вашего сообщения!</p>";
		}
		elseif(!preg_match("/^[a-z0-9_.-]{1,20}@(([a-z0-9-]+\.)+(com|net|org|mil|edu|gov|arpa|info|biz|[a-z]{2})|[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3})$/is",$mail)) {
				print "<p class=\"er\">Введите пожалуйста Ваш e-mail валидно!</p>";
		} elseif(!mysql_num_rows(mysql_query("SELECT * FROM captcha WHERE sid = '".$sid."' AND ip = '".getip()."' AND code = '".$code."'"))) {
			print "<p class=\"er\">Не правильно введён код!</b></font></center></p>";
		} else {

			$headers = "From: ".$mail."\n";
			$headers .= "Reply-to: ".$mail."\n";
			$headers .= "X-Sender: < http://".$cfgURL." >\n";
			$headers .= "Content-Type: text/html; charset=windows-1251\n";

			$textform = "Здравствуйте, ".$name."!<br />Вы писали нам, указав e-mail: ".$mail.", как контактный следующее:<p> >".$textform."</p>";

			$send = mail($adminmail,$subj,$textform,$headers);

			if(!$send) {
				print "<p class=\"er\">Ошибка почтового сервера!<br />Приносим извинения за предоставленные неудобства.</p>";
			} else {

				print "<p class=\"erok\">Ваше сообщение отправлено!</p>";

				$name		= "";
				$mail		= "";
				$subj		= "";
				$textform	= "";
			}
		}
	}
?>
<div class="content" data-ix="anim-load">
    <div class="wrap-title wrap--page">
        <div>
            <h3 class="title-page title--margin16">Создать тикет</h3>
            <div class="subtitle page--tickets">Нужна помощь? Создайте обращение в службу поддержки.</div>
            <div class="subtitle page--tickets">Но прежде мы рекомендуем ознакомиться с разделом <a href="/start#tab5" target="_blank" style="text-decoration: underline;">FAQ</a></div>
        </div>

            </div>
    <div class="columns-tickets-revers w-row">

        
        <div class="col-left w-col w-col-12 w-col-stack">
            <div class="block-form w-form">

        

<form action="?action=submit" method="post" class="form-tickets">

                        <div data-duration-in="300" data-duration-out="100">

                            <div class="">
                                <div>
                                    <div class="block block--ticket">
                                        <div class="ticket-inputs">

                                            <div class="wrap-input wrap--100">
                                                <label for="Subject">Тема</label>
                                                <input type="text" class="input w-input" maxlength="50" name="subj" size="50"  value="<?php print $subj; ?>"  data-name="Subject" placeholder="Введите название темы">
                                            </div>
											
											<input  type="hidden" name="name"  value="<?php if(!$name) { print $login; } else { print $name; } ?>" />
											
											
											<input type="hidden"  name="mail" size="50" maxlength="50" value="<?php if(!$mail) { print $user_mail; } else { print $mail; } ?>" 
											
                                            <div class="wrap-input wrap--50">
                                                <label >Отдел</label>
                                                <select class="select--custom w-select">
                                                    <option value="1">Техническая поддержка</option>
													<option value="2">Финансовый отдел</option>
                                                </select>
                                            </div>
                                            <div class="wrap-input wrap--50">
                                                <label>Приоритет</label>
                                                <select  name="title" data-name="Priority" class="select--custom w-select">
                                                    <option value="1">Низкий</option>
                                                    <option value="2">Высокий</option>
                                                </select>
                                            </div>
                                            <div class="wrap-input wrap--100">
                                                <label class="label">Сообщение</label>
                                                <textarea placeholder="Текст..." maxlength="5000" name="textform"  class="input-area w-input"><?php print $textform; ?></textarea>
                                            </div>


                            
                                              <div class="ticket__wrap-btns">
                                                <input type="submit" value="Отправить" class="btn btn--ticket w-button"></div>
                                        </div>
                        </div>
                                
                    
                        </div>
                    </form>
                    <div class="w-form-done">
                        <div>Thank you! Your submission has been received!</div>
                    </div>
                    <div class="w-form-fail">
                        <div>Oops! Something went wrong while submitting the form.</div>
                    </div>
                </div>
            </div>


        
    </div>
</div>