<?php
	$page = 'contacts';
	$file = 'contacts.php';
	$idpg = 25;
	include '../cfg.php';
	include '../ini.php';
	if($lng == "ru") {
		include "../template_lk_ru.php";
	} else {
		include "../template_lk_ru.php";
	}
?>