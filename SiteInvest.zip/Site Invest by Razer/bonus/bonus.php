<?php
print $body;
defined('ACCESS') or die();
if(cfgSET('cfgBonusOnOff') == "on" && cfgSET('cfgBonusBal') == "on" && $login) {

	if($_GET['act'] == "bon") {

		$sql	= 'SELECT * FROM bonus WHERE user_id = '.$user_id.' order by id DESC LIMIT 1';
		$rs		= mysql_query($sql);

		$a = mysql_fetch_array($rs);

			if($a['date'] < (time() - (cfgSET('cfgBonusPeriod') * 60))) {

				$bonus = rand(cfgSET('cfgBonusMin'),cfgSET('cfgBonusMax')) / 100;

				$sql = "INSERT INTO bonus (login, user_id, sum, date) VALUES ('".$login."', ".$user_id.", ".$bonus.", ".time().")";
				mysql_query($sql);
	
				mysql_query("UPDATE users SET bonus = bonus + ".$bonus." WHERE id = ".$user_id." LIMIT 1");

				print '<p class="erok">You have received a bonus '.$bonus.' '.$moneycurr.'</p>';


			} elseif($a['date'] == "") {
				$bonus = rand(cfgSET('cfgBonusMin'),cfgSET('cfgBonusMax')) / 100;

				$sql = "INSERT INTO bonus (login, user_id, sum, date) VALUES ('".$login."', ".$user_id.", ".$bonus.", ".time().")";
				mysql_query($sql);
	
				mysql_query("UPDATE users SET bonus = bonus + ".$bonus." WHERE id = ".$user_id." LIMIT 1");

				print '<p class="erok">You have received a bonus '.$bonus.' '.$moneycurr.'</p>';

			} else {
				print '<p class="er">You have already get bonuses. Next you will get bonus '.date("d.m.Y � H:i:s", intval($a['date'] + (cfgSET('cfgBonusPeriod') * 60))).'</p>';
			}

	}

	$sql	= 'SELECT * FROM bonus WHERE user_id = '.$user_id.' order by id DESC LIMIT 1';
	$rs		= mysql_query($sql);
	if(mysql_num_rows($rs)) {

		while($a = mysql_fetch_array($rs)) {
			if($a['date'] < (time() - intval(cfgSET('cfgBonusPeriod') * 60))) {
				print '<center><input class="subm" style="width: 98%;" type="button" value="GET BONUS" onclick="top.location.href=\'?act=bon\'" /></center>';
			} else {
				print '<p class="warn">You have already get bonuses. Next you will get bonus '.date("d.m.Y � H:i:s", intval($a['date'] + (cfgSET('cfgBonusPeriod') * 60))).'</p>';
			}
		}

	} else {

		print '<center><input class="subm" style="width: 98%;" type="button" value="GET BONUS" onclick="top.location.href=\'?act=bon\'" /></center>';

	}

print '<hr>';

print '<h3>Last bonuses:</h3>
<table width="100%" border="0" cellpadding="2" cellspacing="1" bgcolor="#eeeeee">
<tr align="center" bgcolor="#ccffcc" style="background:URL(/images/title_bg.gif) repeat-x top left;">
	<td><b>Date:</b></td>
	<td><b>Login:</b></td>
	<td><b>Amount:</b></td>
</tr>';

	$sql	= 'SELECT * FROM bonus order by id DESC LIMIT 50';
	$rs		= mysql_query($sql);
	if(mysql_num_rows($rs)) {

		while($a = mysql_fetch_array($rs)) {
				print "<tr bgcolor=\"#ffffff\" align=\"center\">
				<td align=\"left\">".date("d.m.Y H:i", $a['date'])."</td>
				<td>".$a['login']."</td>
				<td>".$a['sum']." ".$moneycurr."</td>
				</tr>";
		}

	} else {
		print "<tr bgcolor=\"#ffffff\"><td colspan=\"3\" align=\"center\">No data</td></tr>";
	}
print "</table>";

} else {
	print '<p class="er">To access this page you must be logged</p>';
}
?>